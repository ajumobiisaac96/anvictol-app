"use client";

import { useState, useRef, useEffect } from "react";
import faqData from "./faq-data";

// Smart FAQ matcher with better keyword recognition
function findBestMatch(userInput) {
  const input = userInput.toLowerCase();

  const contactKeywords = [
    "contact",
    "whatsapp",
    "phone",
    "call",
    "reach",
    "message",
    "communicate",
    "talk",
  ];
  if (contactKeywords.some((keyword) => input.includes(keyword))) {
    const contactFaq = faqData.find((faq) =>
      faq.question.toLowerCase().includes("contact")
    );
    if (contactFaq) return contactFaq.answer;
  }

  const greetings = [
    "hello",
    "hi",
    "hey",
    "good morning",
    "good afternoon",
    "good evening",
  ];
  if (greetings.some((greeting) => input.includes(greeting))) {
    return "Hello! Welcome to Anvictol Integrated Services. 👋 How can I help you today? I can answer questions about our conveyor cleaning, factory maintenance, line operations, emergency repairs, or how to contact us.";
  }

  let bestMatch = null;
  let bestScore = 0;

  faqData.forEach((faq) => {
    const question = faq.question.toLowerCase();
    const answer = faq.answer.toLowerCase();
    const combinedText = question + " " + answer;

    let score = 0;
    const words = input.split(" ").filter((w) => w.length > 2);

    words.forEach((word) => {
      if (combinedText.includes(word)) score += 10;
      if (question.includes(word)) score += 20;
    });

    if (score > bestScore) {
      bestScore = score;
      bestMatch = faq;
    }
  });

  if (bestMatch && bestScore > 0) {
    return bestMatch.answer;
  }

  return "I'm not sure about that specific question, but I can help you with information about our services. Feel free to ask about our conveyor cleaning, factory maintenance, line operations, emergency repairs, or how to contact us. If you need more specific assistance, you can reach our team directly via WhatsApp!";
}

export default function AIChatModal({ isOpen, onClose }) {
  const [messages, setMessages] = useState([]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      const welcomeMessage = {
        id: 1,
        text: "Hello! 👋 Welcome to Anvictol Integrated Services. I'm here to answer your questions about our conveyor cleaning, factory maintenance, and line operations services. How can I help you today?",
        sender: "bot",
        timestamp: new Date(),
      };
      setMessages([welcomeMessage]);
    }
  }, [isOpen]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = (e) => {
    e.preventDefault();

    if (!inputValue.trim()) return;

    const userMessage = {
      id: messages.length + 1,
      text: inputValue,
      sender: "user",
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue("");
    setIsLoading(true);

    setTimeout(() => {
      const answer = findBestMatch(inputValue);
      const botResponse = {
        id: messages.length + 2,
        text: answer,
        sender: "bot",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, botResponse]);
      setIsLoading(false);
    }, 500);
  };

  if (!isOpen) return null;

  return (
    <>
      <div
        className="fixed inset-0 bg-black bg-opacity-40 z-40 animate-fadeIn"
        onClick={onClose}
      />

      <div className="fixed bottom-36 right-6 w-80 h-[420px] bg-white rounded-xl shadow-2xl flex flex-col z-50 border border-gray-200 animate-scaleIn">
        {/* Header */}
        <div className="bg-[#0A1F44] text-white p-4 flex justify-between items-center rounded-t-xl">
          <div>
            <h3 className="font-bold text-lg">Chat with Anvictol</h3>
            <p className="text-xs text-gray-300">
              AI Assistant • Always Available
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-white hover:bg-white hover:bg-opacity-20 rounded-full p-2 transition-all duration-300 hover:rotate-90"
            aria-label="Close chat"
          >
            <svg
              className="w-6 h-6"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M6 18L18 6M6 6l12 12"
              />
            </svg>
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-gray-50">
          {messages.map((message, index) => (
            <div
              key={message.id}
              className={`flex ${
                message.sender === "user" ? "justify-end" : "justify-start"
              } animate-slideUp`}
              style={{ animationDelay: `${index * 0.05}s` }}
            >
              <div
                className={`max-w-xs px-4 py-2 rounded-lg transition-all duration-300 ${
                  message.sender === "user"
                    ? "bg-[#0A1F44] text-white rounded-br-none text-sm shadow-md hover:shadow-lg"
                    : "bg-white text-gray-800 border border-gray-200 rounded-bl-none text-sm shadow-sm"
                }`}
              >
                <p className="leading-relaxed">{message.text}</p>
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex justify-start animate-slideUp">
              <div className="bg-white text-gray-800 border border-gray-200 px-4 py-3 rounded-lg rounded-bl-none shadow-sm">
                <div className="flex space-x-2">
                  <div className="w-2 h-2 bg-[#0A1F44] rounded-full animate-bounce"></div>
                  <div
                    className="w-2 h-2 bg-[#0A1F44] rounded-full animate-bounce"
                    style={{ animationDelay: "0.1s" }}
                  ></div>
                  <div
                    className="w-2 h-2 bg-[#0A1F44] rounded-full animate-bounce"
                    style={{ animationDelay: "0.2s" }}
                  ></div>
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="border-t border-gray-200 p-3 bg-white rounded-b-xl">
          <form onSubmit={handleSendMessage} className="flex gap-2">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Ask a question..."
              className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A1F44] text-sm transition-all duration-300"
              disabled={isLoading}
              aria-label="Message input"
            />
            <button
              type="submit"
              disabled={isLoading || !inputValue.trim()}
              className="bg-[#0A1F44] text-white px-3 py-2 rounded-lg hover:bg-opacity-90 transition-all duration-300 disabled:opacity-50 hover:scale-105 active:scale-95"
              aria-label="Send message"
            >
              <svg
                className="w-5 h-5"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"
                />
              </svg>
            </button>
          </form>
        </div>
      </div>
    </>
  );
}
